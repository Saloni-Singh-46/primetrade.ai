#!/usr/bin/env python3
"""
run.py - Minimal MLOps-style batch job.

Loads a YAML config, reads an OHLCV CSV file, computes a rolling mean on
`close`, derives a binary trading signal, and writes structured metrics
(JSON) plus a detailed run log.

Usage:
    python run.py --input data.csv --config config.yaml \
                   --output metrics.json --log-file run.log
"""

import argparse
import json
import logging
import os
import sys
import time

import numpy as np
import pandas as pd
import yaml


REQUIRED_CONFIG_FIELDS = {"seed": int, "window": int, "version": str}


class ConfigError(Exception):
    """Raised when the YAML config is missing, malformed, or invalid."""


class DataError(Exception):
    """Raised when the input dataset is missing, malformed, or invalid."""


def setup_logging(log_file: str) -> logging.Logger:
    """Configure logging to both the given log file and stdout/stderr."""
    logger = logging.getLogger("mlops_task")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    file_handler = logging.FileHandler(log_file, mode="w")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(fmt)
    logger.addHandler(console_handler)

    return logger


def load_config(config_path: str, logger: logging.Logger) -> dict:
    """Load and validate the YAML config file."""
    if not os.path.isfile(config_path):
        raise ConfigError(f"Config file not found: {config_path}")

    try:
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ConfigError(f"Invalid YAML in config file: {e}")

    if not isinstance(config, dict):
        raise ConfigError("Config file must define a top-level mapping (dict).")

    for field, expected_type in REQUIRED_CONFIG_FIELDS.items():
        if field not in config:
            raise ConfigError(f"Missing required config field: '{field}'")
        if not isinstance(config[field], expected_type):
            raise ConfigError(
                f"Config field '{field}' must be of type {expected_type.__name__}, "
                f"got {type(config[field]).__name__}"
            )

    if config["window"] <= 0:
        raise ConfigError("Config field 'window' must be a positive integer.")

    logger.info(
        "Config loaded and validated: seed=%s, window=%s, version=%s",
        config["seed"], config["window"], config["version"],
    )
    return config


def load_dataset(input_path: str, logger: logging.Logger) -> pd.DataFrame:
    """Load and validate the input OHLCV dataset."""
    if not os.path.isfile(input_path):
        raise DataError(f"Input file not found: {input_path}")

    if os.path.getsize(input_path) == 0:
        raise DataError(f"Input file is empty: {input_path}")

    try:
        df = pd.read_csv(input_path)
    except pd.errors.EmptyDataError:
        raise DataError(f"Input file has no parsable data: {input_path}")
    except pd.errors.ParserError as e:
        raise DataError(f"Invalid CSV format: {e}")

    if df.empty:
        raise DataError("Input file contains no data rows.")

    if "close" not in df.columns:
        raise DataError("Required column 'close' not found in input data.")

    if not pd.api.types.is_numeric_dtype(df["close"]):
        df["close"] = pd.to_numeric(df["close"], errors="coerce")
        if df["close"].isna().all():
            raise DataError("Column 'close' contains no valid numeric data.")

    logger.info("Dataset loaded: %d rows from %s", len(df), input_path)
    return df


def compute_signal(df: pd.DataFrame, window: int, logger: logging.Logger) -> pd.DataFrame:
    """Compute rolling mean on `close` and derive a binary signal.

    The first (window - 1) rows do not have enough history for a full
    rolling window, so the rolling mean is NaN there (min_periods=window).
    Those rows are consistently assigned signal=0 (close > NaN is False),
    and are excluded from being counted as "active" signals while still
    being included in rows_processed / signal_rate denominators.
    """
    df["rolling_mean"] = df["close"].rolling(window=window, min_periods=window).mean()
    df["signal"] = (df["close"] > df["rolling_mean"]).astype(int)

    logger.info("Rolling mean computed with window=%d", window)
    logger.info(
        "Signal generated: %d rows with insufficient history (window-1) set to signal=0",
        window - 1,
    )
    return df


def main():
    parser = argparse.ArgumentParser(description="Minimal MLOps batch job.")
    parser.add_argument("--input", required=True, help="Path to input CSV file")
    parser.add_argument("--config", required=True, help="Path to YAML config file")
    parser.add_argument("--output", required=True, help="Path to output metrics JSON")
    parser.add_argument("--log-file", required=True, help="Path to output log file")
    args = parser.parse_args()

    logger = setup_logging(args.log_file)
    start_time = time.perf_counter()
    logger.info("Job started")

    version = "v1"  # fallback if config fails before it's read
    seed = None

    try:
        config = load_config(args.config, logger)
        version = config["version"]
        seed = config["seed"]
        window = config["window"]

        np.random.seed(seed)
        logger.info("Random seed set to %d", seed)

        df = load_dataset(args.input, logger)
        df = compute_signal(df, window, logger)

        rows_processed = int(len(df))
        signal_rate = float(df["signal"].mean())
        latency_ms = int(round((time.perf_counter() - start_time) * 1000))

        metrics = {
            "version": version,
            "rows_processed": rows_processed,
            "metric": "signal_rate",
            "value": round(signal_rate, 4),
            "latency_ms": latency_ms,
            "seed": seed,
            "status": "success",
        }

        logger.info(
            "Metrics summary: rows_processed=%d, signal_rate=%.4f, latency_ms=%d",
            rows_processed, signal_rate, latency_ms,
        )

        with open(args.output, "w") as f:
            json.dump(metrics, f, indent=2)

        logger.info("Metrics written to %s", args.output)
        logger.info("Job ended: status=success")

        print(json.dumps(metrics, indent=2))
        sys.exit(0)

    except (ConfigError, DataError) as e:
        error_metrics = {
            "version": version,
            "status": "error",
            "error_message": str(e),
        }
        logger.error("Validation error: %s", str(e))

        try:
            with open(args.output, "w") as f:
                json.dump(error_metrics, f, indent=2)
            logger.info("Error metrics written to %s", args.output)
        except OSError as write_err:
            logger.error("Failed to write error metrics: %s", write_err)

        logger.info("Job ended: status=error")
        print(json.dumps(error_metrics, indent=2))
        sys.exit(1)

    except Exception as e:
        error_metrics = {
            "version": version,
            "status": "error",
            "error_message": f"Unexpected error: {e}",
        }
        logger.exception("Unexpected error occurred")

        try:
            with open(args.output, "w") as f:
                json.dump(error_metrics, f, indent=2)
            logger.info("Error metrics written to %s", args.output)
        except OSError as write_err:
            logger.error("Failed to write error metrics: %s", write_err)

        logger.info("Job ended: status=error")
        print(json.dumps(error_metrics, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
